import httplib2
import os
from apiclient import discovery
import python_for_gmail  # 先ほど作成したプログラム
import winsound
import time
import random

#cmdにpython3.x入れて> python get_mail.pyするか、VSCode上から動かしてくださいまし
#何秒に1度チェックしたい？？300未満だと503エラー返ってくるかも。
RELOAD_TIME = 360
#○秒に一度最新のメール○件をチェック(小さめにしてね)
CHECK_MAIL_NUM = 10
# 何分自動で通知鳴らしたい？（本当に邪魔ならプログラムをCtrl+Cで止めてね）
# 1日は1440分だよ、12時間なら720
CALL_TIME = 720

with open('sample.wav', 'rb') as f:
    data = f.read()
crnt = 0
call_timestamp = 60 * CALL_TIME
num = 0
is_alert = False
ALERT_MODE = 10 #アラート状態になったら目覚まし何度も鳴らす

# Gmailのサービスを取得
def gmail_get_service():
    # ユーザー認証の取得
    credentials = python_for_gmail.gmail_user_auth()
    http = credentials.authorize(httplib2.Http())
    # GmailのAPIを利用する
    service = discovery.build('gmail', 'v1', http=http)
    return service

# メッセージの一覧を取得
def gmail_get_messages():
    # http://www.ops.dti.ne.jp/ironpython.beginner/global.html
    global is_alert
    try:
        service = gmail_get_service()
        # メッセージの一覧を取得
        messages = service.users().messages()
        msg_list = messages.list(userId='me', maxResults=10).execute()

        # 取得したメッセージの一覧を表示
        for msg in msg_list['messages']:
            topid = msg['id']
            msg = messages.get(userId='me', id=topid).execute()
            recv_time = int(int(msg['internalDate'])/1000)
            if '御伽原 江良 / Otogibara Era【にじさんじ】' in msg['snippet']:
                call_time = crnt - recv_time - call_timestamp
                if call_time < 0:
                    print("---")
                    print(msg['snippet'])  # 要約を表示
                    winsound.PlaySound(data, winsound.SND_MEMORY)
                    is_alert = True
                print(call_time)
        print(crnt)
    except Exception as e:
        print("取得失敗したみたい…")
        print(e)
        return

# メッセージの取得
# 無限に実行されても困るので
while num < 99999999999:
    print('======== phase' + str(num) + ' ========')
    num += 1
    crnt = int(time.time())
    rand_sleep = int(random.uniform(10, -10)) # 定期実行だと503呼ばれそうなので、回避
    #アラートモードになったらずっとアラート音ならして、それ以上APIを呼ばない
    if is_alert:
        winsound.PlaySound(data, winsound.SND_MEMORY)
        print("waiting "  + str(ALERT_MODE) + "sec...")
        time.sleep(ALERT_MODE)
        continue
    gmail_get_messages()
    sleep_time = RELOAD_TIME + rand_sleep
    if is_alert == False:
        print("waiting "  + str(sleep_time) + "sec...")
        time.sleep(sleep_time)

#TODO printでログ出すのはかしこくないので誰かlogger使って置き換えて